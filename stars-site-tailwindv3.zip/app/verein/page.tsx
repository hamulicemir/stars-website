export default function Page() {
  return (
    <div className="container-7xl py-10">
      <h1 className="text-3xl font-bold">Verein</h1>
      <p className="mt-3 text-slate-700">Über uns, Philosophie, Ansprechpartner, Hallen, Kontakt.</p>
    </div>
  );
}
