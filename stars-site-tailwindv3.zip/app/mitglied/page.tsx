export default function Page() {
  return (
    <div className="container-7xl py-10">
      <h1 className="text-3xl font-bold">Mitglied werden</h1>
      <p className="mt-3 text-slate-700">Infos zur Anmeldung und zu Probetrainings – Formular/Link.</p>
    </div>
  );
}
