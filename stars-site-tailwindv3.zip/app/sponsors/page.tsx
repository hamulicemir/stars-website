export default function Page() {
  return (
    <div className="container-7xl py-10">
      <h1 className="text-3xl font-bold">Sponsoring</h1>
      <p className="mt-3 text-slate-700">Unsere Partner & Unterstützer – Logos, Links und kurze Beschreibungen.</p>
    </div>
  );
}
