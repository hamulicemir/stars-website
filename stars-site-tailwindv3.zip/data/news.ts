export type NewsItem = { id: number; title: string; excerpt: string; date: string; tag: string; slug: string };
export const news: NewsItem[] = [
  { id: 1, title: "U16 holt Derbysieg – starke Defense entscheidet", excerpt: "Im Heimspiel gegen die Nachbarn setzte sich unsere U16 mit 62:54 durch.", date: "2025-09-12", tag: "Spielbericht", slug: "u16-derbysieg" },
  { id: 2, title: "Tryouts Herbst – jetzt anmelden!", excerpt: "Offene Trainings für U10–U18 sowie Girls-Only-Sessions.", date: "2025-09-05", tag: "Verein", slug: "tryouts-herbst" },
  { id: 3, title: "Sommercamp Recap: Skills, Spaß & neue Friends", excerpt: "Über 80 Kids, 12 Coaches, 5 Tage voller Basketball.", date: "2025-08-28", tag: "Camp", slug: "sommercamp-recap" },
];
