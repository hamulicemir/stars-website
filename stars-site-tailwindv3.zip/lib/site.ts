export const site = {
  name: "STARS BASKETBALL",
  description: "Nachwuchsförderung und Breitensport – von U10 bis U19, Girls-Only-Programme und Camps.",
  links: {
    instagram: "#",
    youtube: "#",
  },
};
