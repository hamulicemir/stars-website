import React from "react";
import { CalendarDays, Newspaper, Images, Users, Award, Play, ChevronRight } from "lucide-react";
import { Container } from "./ui/container";
import { Button } from "./ui/button";
import { Pill } from "./ui/pill";
import { Card } from "./ui/card";
import { gallery } from "@/data/media";
import { news } from "@/data/news";
import { teams } from "@/data/teams";

export default function Landing() {
  return (
    <div id="home">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -left-10 top-10 h-64 w-64 rounded-full bg-gradient-to-br from-orange-400/10 to-red-400/10 blur-3xl" />
          <div className="absolute right-0 top-40 h-72 w-72 rounded-full bg-gradient-to-br from-fuchsia-400/10 to-indigo-400/10 blur-3xl" />
        </div>
        <Container className="grid items-center gap-8 py-14 md:grid-cols-2 md:py-20">
          <div>
            <Pill><CalendarDays size={16} className="mr-2" /> Nächstes Heimspiel · Samstag 19:30</Pill>
            <h1 className="mt-4 text-4xl font-black leading-tight tracking-tight md:text-5xl">
              Leidenschaft. Teamgeist. <span className="bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">Stars Basketball</span>
            </h1>
            <p className="mt-4 max-w-xl text-slate-700">
              Nachwuchsförderung und Breitensport – von U10 bis U19, Girls-Only-Programme und Camps. Komm ins Team!
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/news"><Newspaper size={18}/> Aktuelle News</Button>
              <Button href="/media" variant="ghost"><Play size={18}/> Highlights ansehen</Button>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] w-full overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-br from-slate-100 to-white">
              <div className="flex h-full w-full items-center justify-center">
                <div className="grid grid-cols-3 gap-2 p-6 md:gap-3">
                  {Array.from({length: 9}).map((_, i) => (
                    <div key={i} className="aspect-square rounded-xl bg-slate-50 ring-1 ring-slate-200" />
                  ))}
                </div>
              </div>
            </div>
            <Card className="absolute -bottom-6 left-6 hidden w-64 md:block">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-orange-500 to-red-500" />
                <div>
                  <p className="text-xs uppercase tracking-wide text-slate-500">Record</p>
                  <p className="text-sm font-semibold">5–1 (Last 6)</p>
                </div>
              </div>
            </Card>
          </div>
        </Container>
      </section>

      {/* Highlights */}
      <section className="border-b border-slate-200">
        <Container className="grid gap-4 py-8 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <div className="flex items-center gap-3">
              <Award className="opacity-90" />
              <div>
                <p className="text-sm font-semibold">Programm</p>
                <p className="text-xs text-slate-600">U10–U19 & Girls</p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-center gap-3">
              <Users className="opacity-90" />
              <div>
                <p className="text-sm font-semibold">12+ Coaches</p>
                <p className="text-xs text-slate-600">Lizenzierte Trainer*innen</p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-center gap-3">
              <Images className="opacity-90" />
              <div>
                <p className="text-sm font-semibold">Media</p>
                <p className="text-xs text-slate-600">Fotos & Videos</p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-center gap-3">
              <CalendarDays className="opacity-90" />
              <div>
                <p className="text-sm font-semibold">Trainingszeiten</p>
                <p className="text-xs text-slate-600">Alle Teams</p>
              </div>
            </div>
          </Card>
        </Container>
      </section>

      {/* News */}
      <section className="border-b border-slate-200 py-12 md:py-16">
        <Container>
          <div className="flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold md:text-3xl">Aktuelle News</h2>
              <p className="mt-1 text-sm text-slate-600">Spielberichte, Ankündigungen, Camps & mehr</p>
            </div>
            <a href="/news" className="group hidden text-sm text-slate-700 hover:text-gray-900 md:inline-flex">
              Alle Beiträge <ChevronRight className="ml-1 transition group-hover:translate-x-0.5" size={16} />
            </a>
          </div>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {news.map((n) => (
              <article key={n.id} className="group rounded-2xl border border-slate-200 bg-white p-5 transition hover:bg-slate-50">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="rounded-full bg-slate-100 px-2 py-0.5">{n.tag}</span>
                  <time>{new Date(n.date).toLocaleDateString("de-AT")}</time>
                </div>
                <h3 className="mt-3 text-lg font-semibold leading-snug group-hover:underline">
                  <a href={`/news/${n.slug}`}>{n.title}</a>
                </h3>
                <p className="mt-2 line-clamp-3 text-sm text-slate-700">{n.excerpt}</p>
              </article>
            ))}
          </div>
        </Container>
      </section>

      {/* Teams */}
      <section className="border-b border-slate-200 py-12 md:py-16">
        <Container>
          <div className="mb-8">
            <h2 className="text-2xl font-bold md:text-3xl">Unsere Teams</h2>
            <p className="mt-1 text-sm text-slate-600">Trainingszeiten, Coaches, Spieltermine</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {teams.map((t) => (
              <div key={t.id} className="group rounded-2xl border border-slate-200 bg-white">
                <div className={`h-28 w-full rounded-t-2xl bg-gradient-to-r ${t.color}`} />
                <div className="p-5">
                  <h3 className="text-lg font-semibold">{t.name}</h3>
                  <p className="text-sm text-slate-600">Coach: {t.coach}</p>
                  <div className="mt-4 flex gap-2">
                    <a href={`/teams/${t.id}`} className="text-sm text-slate-700 hover:underline">Trainingszeiten</a>
                    <span className="text-slate-300">•</span>
                    <a href={`/teams/${t.id}`} className="text-sm text-slate-700 hover:underline">Spielplan</a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* Media */}
      <section className="border-b border-slate-200 py-12 md:py-16">
        <Container>
          <div className="mb-8 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold md:text-3xl">Media</h2>
              <p className="mt-1 text-sm text-slate-600">Fotos & Videos aus der Saison</p>
            </div>
            <a href="/media" className="group hidden text-sm text-slate-700 hover:text-gray-900 md:inline-flex">
              Zur Galerie <ChevronRight className="ml-1 transition group-hover:translate-x-0.5" size={16} />
            </a>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
            {gallery.map((g) => (
              <div key={g.id} className={`${g.ratio} overflow-hidden rounded-xl border border-slate-200 bg-white`}>
                <div className="flex h-full items-center justify-center text-xs text-slate-500">{g.alt}</div>
              </div>
            ))}
          </div>
          <Card className="mt-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Play />
              <div>
                <p className="text-sm font-semibold">Game Highlights</p>
                <p className="text-xs text-slate-600">YouTube-Playlist einbetten</p>
              </div>
            </div>
            <Button href="/media">Jetzt ansehen</Button>
          </Card>
        </Container>
      </section>
    </div>
  );
}
