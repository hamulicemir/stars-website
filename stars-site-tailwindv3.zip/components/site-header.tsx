import React from "react";
import { Container } from "./ui/container";
import { Button } from "./ui/button";

const nav = [
  { label: "News", href: "/news" },
  { label: "Teams", href: "/teams" },
  { label: "Media", href: "/media" },
  { label: "Verein", href: "/verein" },
  { label: "Sponsoring", href: "/sponsors" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/80 backdrop-blur">
      <Container className="flex h-16 items-center justify-between">
        <a href="/" className="flex items-center gap-3 text-gray-900">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-orange-500 to-red-500" />
          <span className="text-lg font-extrabold tracking-tight">STARS BASKETBALL</span>
        </a>
        <nav className="hidden gap-6 md:flex">
          {nav.map((n) => (
            <a key={n.href} href={n.href} className="text-sm text-slate-600 hover:text-gray-900">
              {n.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" href="/mitglied">Mitglied werden</Button>
        </div>
      </Container>
    </header>
  );
}
