import React from "react";
import { Container } from "./ui/container";
import { Mail, Phone, MapPin } from "lucide-react";
export function SiteFooter() {
  return (
    <footer className="border-t border-slate-200 py-10">
      <Container className="grid gap-8 sm:grid-cols-2 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-orange-500 to-red-500" />
            <p className="text-sm font-bold">STARS BASKETBALL</p>
          </div>
          <p className="mt-3 text-sm text-slate-600">
            Nachwuchsprogramm, Breiten- und Leistungsbasketball in deiner Region.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Navigation</h4>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            <li><a className="hover:underline" href="/news">News</a></li>
            <li><a className="hover:underline" href="/teams">Teams</a></li>
            <li><a className="hover:underline" href="/media">Media</a></li>
            <li><a className="hover:underline" href="/sponsors">Sponsoring</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Kontakt</h4>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            <li className="flex items-center gap-2"><Mail size={16}/> info@stars-basketball.com</li>
            <li className="flex items-center gap-2"><Phone size={16}/> +43 660 000000</li>
            <li className="flex items-center gap-2"><MapPin size={16}/> Musterhalle, Wien</li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Rechtliches</h4>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            <li><a href="#" className="hover:underline">Impressum</a></li>
            <li><a href="#" className="hover:underline">Datenschutz</a></li>
          </ul>
        </div>
      </Container>
      <Container className="mt-8 border-t border-slate-200 pt-6 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} Stars Basketball. All rights reserved.
      </Container>
    </footer>
  );
}
