import React from "react";
export function Pill({ children }: { children: React.ReactNode }) {
  return <span className="inline-flex items-center rounded-full border border-slate-300 bg-slate-100 px-3 py-1 text-xs font-medium tracking-wide text-slate-700">{children}</span>;
}
