import React from "react";
export function Button({ children, href = "#", variant = "primary" as const }: { children: React.ReactNode; href?: string; variant?: "primary" | "ghost" }) {
  if (variant === "ghost") return <a href={href} className="btn-ghost">{children}</a>;
  return <a href={href} className="btn-primary">{children}</a>;
}
