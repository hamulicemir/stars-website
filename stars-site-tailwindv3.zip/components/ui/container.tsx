import React from "react";
export function Container({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`container-7xl ${className}`}>{children}</div>;
}
